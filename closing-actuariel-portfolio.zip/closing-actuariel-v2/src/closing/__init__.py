"""
closing — Pipeline de clôture actuarielle non-vie

Package Python implémentant l'intégralité de la chaîne de clôture
d'un portefeuille MTPL : simulation du portefeuille, provisionnement,
test d'adéquation IFRS 4, analyse boni-mali, compte technique et
automatisation du processus de closing.

Auteur  : Steve (portfolio actuariel)
Licence : MIT
Version : 1.0.0
"""

__version__ = "1.0.0"
__author__  = "Steve"
